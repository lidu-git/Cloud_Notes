**Please make sure that `dist/*` files aren't committed.**
